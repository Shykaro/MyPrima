Dear developer

 I hope you like these assets. If you need more assets like this you might be interested in my  site,  www.gamedeveloperstudio.com I'm aiming to create a library  of high quality  assets all of which are  economically accessible  to all developers, There are even more free ones like this too.

If you like them or use them why not consider visiting or supporting the site.

You can use these assets in your commercial products you don't have to credit me anyway but if you do I would really appreciate if you credit www.gamedeveloperstudio.com if you would like to credit me with a link please link to https://www.gamedeveloperstudio.com

Thanks 

Robert Brooks

www.gamedeveloperstudio.com
